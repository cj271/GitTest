/// <reference types="vite/client" />

interface Window {
  readonly PKG: Record<string, string>;
}
